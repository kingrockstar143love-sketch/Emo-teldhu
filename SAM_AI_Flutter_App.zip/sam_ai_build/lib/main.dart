import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

void main() => runApp(const SamAiApp());

const purple = Color(0xFF8B45F7);
const pink = Color(0xFFEC35B5);
const bg = Color(0xFF080817);
const panel = Color(0xFF15152B);

class SamAiApp extends StatelessWidget {
  const SamAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SAM.AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
          useMaterial3: true,
          snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
        ),
        home: const SamHome(),
      );
}

class SamHome extends StatefulWidget {
  const SamHome({super.key});
  @override
  State<SamHome> createState() => _SamHomeState();
}

class _SamHomeState extends State<SamHome> {
  int tab = 0;
  String? selectedVideo;
  final projects = <String>[];

  void notice(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  Future<void> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video, allowMultiple: false);
    if (result != null && result.files.isNotEmpty) {
      setState(() {
        selectedVideo = result.files.single.name;
        if (!projects.contains(selectedVideo)) projects.insert(0, selectedVideo!);
      });
      if (mounted) notice('Video selected: $selectedVideo');
    }
  }

  void openFeature(String title) {
    if (title == 'Long video to clips' || title == 'My videos') {
      setState(() => tab = title == 'My videos' ? 3 : 1);
    } else if (title == 'AI video generator') {
      setState(() => tab = 2);
    } else if (title == 'YouTube upload') {
      showDialog<void>(context: context, builder: (_) => const _InfoDialog(title: 'YouTube connection', body: 'YouTube publishing needs Google OAuth credentials and a secure backend. Add your OAuth client configuration before enabling uploads.'));
    } else {
      notice('$title will be available when the SAM.AI processing backend is connected.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _Dashboard(onFeature: openFeature, onPick: pickVideo, selectedVideo: selectedVideo, projectCount: projects.length),
      _ClipsPage(selectedVideo: selectedVideo, onPick: pickVideo, onGenerate: () => notice('AI clip processing requires the SAM.AI backend and transcription/clip-generation service.')),
      _CreatePage(onGenerate: () => notice('Connect an AI video-generation provider and backend API to generate a real video.')),
      _ProjectsPage(projects: projects, onPick: pickVideo),
      const _ProfilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        titleSpacing: 18,
        title: const Row(children: [Icon(Icons.play_circle_fill_rounded, color: purple, size: 31), SizedBox(width: 8), Text('SAM', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 23)), Text('.AI', style: TextStyle(color: pink, fontWeight: FontWeight.w900, fontSize: 23))]),
        actions: [IconButton(onPressed: () => setState(() => tab = 4), icon: const Icon(Icons.account_circle_outlined)), const SizedBox(width: 8)],
      ),
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111126),
        indicatorColor: purple.withValues(alpha: .22),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.content_cut), label: 'Clips'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.video_library_outlined), label: 'Projects'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class _Dashboard extends StatelessWidget {
  const _Dashboard({required this.onFeature, required this.onPick, required this.selectedVideo, required this.projectCount});
  final void Function(String) onFeature;
  final VoidCallback onPick;
  final String? selectedVideo;
  final int projectCount;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 26), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(25), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF49218D), Color(0xFF1B2055), Color(0xFF321344)]), border: Border.all(color: purple.withValues(alpha: .45))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.auto_awesome, color: Colors.amber), SizedBox(width: 7), Text('YOUR AI VIDEO STUDIO', style: TextStyle(letterSpacing: 1.2, fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white70))]),
      const SizedBox(height: 13), const Text('Create videos that\nstop the scroll.', style: TextStyle(fontSize: 29, height: 1.08, fontWeight: FontWeight.w900)),
      const SizedBox(height: 9), const Text('Turn long videos into viral clips or create fresh videos with AI.', style: TextStyle(color: Colors.white70, height: 1.4)),
      const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onPick, icon: const Icon(Icons.cloud_upload_outlined), label: const Text('Upload a video'), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF32145E), padding: const EdgeInsets.symmetric(vertical: 14)))),
      if (selectedVideo != null) ...[const SizedBox(height: 9), Text('Selected: $selectedVideo', style: const TextStyle(color: Colors.white70, fontSize: 12))],
    ])),
    const SizedBox(height: 22), const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Your workspace', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('ALL TOOLS', style: TextStyle(color: purple, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1))]),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 11, crossAxisSpacing: 11, childAspectRatio: 1.18, children: [
      _ToolCard(icon: Icons.content_cut, title: 'Long video to clips', subtitle: 'AI Shorts & highlights', color: purple, onTap: () => onFeature('Long video to clips')),
      _ToolCard(icon: Icons.movie_creation_outlined, title: 'AI video generator', subtitle: 'Text and image to video', color: pink, onTap: () => onFeature('AI video generator')),
      _ToolCard(icon: Icons.auto_fix_high, title: 'AI editing', subtitle: 'Captions, trim & polish', color: Colors.lightBlueAccent, onTap: () => onFeature('AI editing')),
      _ToolCard(icon: Icons.smart_display, title: 'YouTube upload', subtitle: 'Publish your videos', color: Colors.redAccent, onTap: () => onFeature('YouTube upload')),
      _ToolCard(icon: Icons.closed_caption, title: 'Auto captions', subtitle: 'Subtitles & styles', color: Colors.orangeAccent, onTap: () => onFeature('Auto captions')),
      _ToolCard(icon: Icons.mic_none, title: 'AI voiceover', subtitle: 'Natural AI narration', color: Colors.greenAccent, onTap: () => onFeature('AI voiceover')),
    ]),
    const SizedBox(height: 21), const Text('Studio overview', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 11),
    Row(children: [_StatCard(label: 'Projects', value: '$projectCount', icon: Icons.video_library), const SizedBox(width: 10), const _StatCard(label: 'AI clips', value: '—', icon: Icons.auto_awesome), const SizedBox(width: 10), const _StatCard(label: 'Published', value: '—', icon: Icons.rocket_launch)]),
    const SizedBox(height: 18), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: Colors.amber), SizedBox(width: 10), Expanded(child: Text('The app interface and video selection are ready. Real AI processing, cloud storage, account login and YouTube publishing need backend services and API credentials.', style: TextStyle(color: Colors.white70, height: 1.45, fontSize: 12)))])),
  ]);
}

class _ToolCard extends StatelessWidget {
  const _ToolCard({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final IconData icon; final String title, subtitle; final Color color; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(color: panel, borderRadius: BorderRadius.circular(18), child: InkWell(borderRadius: BorderRadius.circular(18), onTap: onTap, child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withValues(alpha: .15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color, size: 23)), const Spacer(), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11))]))));
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.icon});
  final String label, value; final IconData icon;
  @override
  Widget build(BuildContext context) => Expanded(child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: purple, size: 18), const SizedBox(height: 10), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10))])));
}

class _ClipsPage extends StatelessWidget {
  const _ClipsPage({required this.selectedVideo, required this.onPick, required this.onGenerate});
  final String? selectedVideo; final VoidCallback onPick, onGenerate;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const _PageHeading(title: 'Long video to clips', subtitle: 'Find the best moments and turn them into short-form videos.'), const SizedBox(height: 20), _UploadBox(selectedVideo: selectedVideo, onPick: onPick), const SizedBox(height: 18), const Text('Clip settings', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 12), const _SettingTile(icon: Icons.aspect_ratio, title: 'Aspect ratio', value: '9:16 Vertical'), const _SettingTile(icon: Icons.timer_outlined, title: 'Clip duration', value: '30–60 seconds'), const _SettingTile(icon: Icons.closed_caption, title: 'Captions', value: 'Auto captions enabled'), const _SettingTile(icon: Icons.face_retouching_natural, title: 'Smart framing', value: 'Face tracking'), const SizedBox(height: 18), FilledButton.icon(onPressed: onGenerate, icon: const Icon(Icons.auto_awesome), label: const Text('Generate viral clips'), style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16)))]);
}

class _CreatePage extends StatefulWidget {
  const _CreatePage({required this.onGenerate}); final VoidCallback onGenerate;
  @override State<_CreatePage> createState() => _CreatePageState();
}
class _CreatePageState extends State<_CreatePage> {
  final prompt = TextEditingController(); String mode = 'Text to video'; String ratio = '16:9 Landscape';
  @override void dispose() { prompt.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const _PageHeading(title: 'AI video generator', subtitle: 'Describe your idea and prepare a video with AI.'), const SizedBox(height: 20), SegmentedButton<String>(segments: const [ButtonSegment(value: 'Text to video', label: Text('Text to video'), icon: Icon(Icons.text_fields)), ButtonSegment(value: 'Image to video', label: Text('Image to video'), icon: Icon(Icons.image_outlined))], selected: {mode}, onSelectionChanged: (v) => setState(() => mode = v.first)), const SizedBox(height: 18), const Text('Describe your video', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 9), TextField(controller: prompt, minLines: 5, maxLines: 7, decoration: InputDecoration(hintText: 'Example: A cinematic travel video of a beautiful mountain sunrise...', filled: true, fillColor: panel, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))), const SizedBox(height: 18), const Text('Video format', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 9), DropdownButtonFormField<String>(value: ratio, decoration: InputDecoration(filled: true, fillColor: panel, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)), items: const [DropdownMenuItem(value: '16:9 Landscape', child: Text('16:9 Landscape')), DropdownMenuItem(value: '9:16 Vertical', child: Text('9:16 Vertical')), DropdownMenuItem(value: '1:1 Square', child: Text('1:1 Square'))], onChanged: (v) => setState(() => ratio = v ?? ratio)), const SizedBox(height: 22), FilledButton.icon(onPressed: widget.onGenerate, icon: const Icon(Icons.auto_awesome), label: const Text('Generate video'), style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16))), const SizedBox(height: 12), const Text('Generation requires a connected AI video provider. Your prompt is not sent anywhere in this demo.', style: TextStyle(color: Colors.white54, fontSize: 12))]);
}

class _ProjectsPage extends StatelessWidget {
  const _ProjectsPage({required this.projects, required this.onPick}); final List<String> projects; final VoidCallback onPick;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const _PageHeading(title: 'My projects', subtitle: 'Your imported videos and creative workspace.'), const SizedBox(height: 18), FilledButton.icon(onPressed: onPick, icon: const Icon(Icons.add), label: const Text('Import video'), style: FilledButton.styleFrom(backgroundColor: purple)), const SizedBox(height: 15), if (projects.isEmpty) const _EmptyState(icon: Icons.video_library_outlined, title: 'No projects yet', body: 'Import a video to start creating with SAM.AI.') else ...projects.map((p) => Card(color: panel, child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0x332A9DFF), child: Icon(Icons.video_file, color: Colors.lightBlueAccent)), title: Text(p, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: const Text('Imported video'), trailing: const Icon(Icons.more_vert))))]);
}

class _ProfilePage extends StatelessWidget {
  const _ProfilePage();
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const _PageHeading(title: 'Your account', subtitle: 'Manage your SAM.AI workspace.'), const SizedBox(height: 25), const CircleAvatar(radius: 38, backgroundColor: Color(0x332A1B66), child: Icon(Icons.person, size: 42, color: purple)), const SizedBox(height: 12), const Center(child: Text('Guest user', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), const Center(child: Text('Sign-in will be enabled after authentication setup.', style: TextStyle(color: Colors.white54, fontSize: 12))), const SizedBox(height: 24), const _SettingTile(icon: Icons.login, title: 'Google / Email login', value: 'Backend setup required'), const _SettingTile(icon: Icons.smart_display, title: 'YouTube account', value: 'Not connected'), const _SettingTile(icon: Icons.workspace_premium_outlined, title: 'Subscription', value: 'Free preview'), const _SettingTile(icon: Icons.settings_outlined, title: 'Settings', value: 'App preferences')]);
}

class _PageHeading extends StatelessWidget { const _PageHeading({required this.title, required this.subtitle}); final String title, subtitle; @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(color: Colors.white60, height: 1.4))]); }
class _UploadBox extends StatelessWidget { const _UploadBox({required this.selectedVideo, required this.onPick}); final String? selectedVideo; final VoidCallback onPick; @override Widget build(BuildContext context) => InkWell(onTap: onPick, borderRadius: BorderRadius.circular(18), child: Container(padding: const EdgeInsets.all(23), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: purple.withValues(alpha: .65), style: BorderStyle.solid)), child: Column(children: [const Icon(Icons.cloud_upload_outlined, color: purple, size: 42), const SizedBox(height: 10), Text(selectedVideo ?? 'Choose a long video', style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 5), const Text('Tap to browse video files on your device', style: TextStyle(color: Colors.white54, fontSize: 12))]))); }
class _SettingTile extends StatelessWidget { const _SettingTile({required this.icon, required this.title, required this.value}); final IconData icon; final String title, value; @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 9), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)), child: ListTile(leading: Icon(icon, color: purple), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)), trailing: Text(value, style: const TextStyle(color: Colors.white54, fontSize: 11)))); }
class _EmptyState extends StatelessWidget { const _EmptyState({required this.icon, required this.title, required this.body}); final IconData icon; final String title, body; @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 50), child: Column(children: [Icon(icon, size: 48, color: Colors.white30), const SizedBox(height: 12), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 6), Text(body, style: const TextStyle(color: Colors.white54), textAlign: TextAlign.center)])); }
class _InfoDialog extends StatelessWidget { const _InfoDialog({required this.title, required this.body}); final String title, body; @override Widget build(BuildContext context) => AlertDialog(backgroundColor: panel, title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]); }
