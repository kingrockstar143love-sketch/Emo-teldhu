# SAM.AI — Smart AI Video Creator

Flutter Android starter with a dark purple SAM.AI workspace, navigation, video file selection, long-video-to-clips settings, AI video prompt screen, project list, YouTube integration entry point, and profile/settings UI.

## Build APK with GitHub Actions
1. Upload the **contents** of this folder to the root of a GitHub repository (not the enclosing folder and not just the ZIP).
2. Commit to `main`.
3. Open **Actions → SAM.AI Android APK Build**.
4. Wait for a green check, open the run, and download artifact **SAM-AI-APK**.
5. Extract the artifact ZIP; install `app-release.apk` on Android.

## Local build
```bash
flutter pub get
 dart format lib test
flutter analyze
flutter test
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`

## Important implementation status
This is a working Flutter UI prototype. Local video selection is implemented. Actual AI highlight detection, transcription, clip rendering, AI video generation, cloud project storage, authentication, analytics, and automatic YouTube publishing are **not yet connected**. They require a secure backend, storage, AI/video-processing providers, and Google/YouTube OAuth credentials. Do not put private API keys in the Flutter app; keep them on the backend.
