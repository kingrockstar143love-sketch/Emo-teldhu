import 'package:flutter_test/flutter_test.dart';
import 'package:sam_ai/main.dart';

void main() {
  testWidgets('SAM.AI dashboard renders core tools', (tester) async {
    await tester.pumpWidget(const SamAiApp());
    expect(find.text('SAM'), findsOneWidget);
    expect(find.text('Long video to clips'), findsOneWidget);
    expect(find.text('AI video generator'), findsOneWidget);
    expect(find.text('YouTube upload'), findsOneWidget);
  });
}
